SSH Key for DB node access is /nas/pocs/fiserv166441/fiserv166441cluster.key. The following is an example of how to use the key:
cp /nas/pocs/fiserv166441/fiserv166441cluster.key ~
chmod 600 ~/fiserv166441cluster.key
nNodes=2;nodeName=ecc9c1;domName=us.osc.oracle.com;myDBnum=0
ssh -i ~/fiserv166441cluster.key -l opc $nodeName"n"$((($myDBnum+1)%$nNodes)).$domName
OR the following is a short cut but may not work in all situation
ssh -i ~/fiserv166441cluster.key -l opc ecc9c1n1
